import rclpy
from rclpy.node import Node
from geometry_msgs.msg import AccelStamped
from sensor_msgs.msg import Imu
import math

class IMUOrientationPublisher(Node):
    def __init__(self):
        super().__init__('imu_orientation_publisher')

        # Subscribe to your existing /accel_data topic
        self.sub_accel = self.create_subscription(
            AccelStamped,
            'accel_data',
            self.accel_callback,
            10
        )

        # Publish as an IMU message
        self.pub_imu = self.create_publisher(Imu, 'imu/data', 10)

        self.get_logger().info("IMUOrientationPublisher node started.")

    def accel_callback(self, accel_msg: AccelStamped):
        """
        We'll treat accel_msg.accel.angular.x as roll_deg
        and accel_msg.accel.angular.y as pitch_deg (both in degrees).
        We'll assume yaw=0 for demonstration.
        """
        roll_deg = accel_msg.accel.angular.x
        pitch_deg = accel_msg.accel.angular.y

        # Convert degrees -> radians
        roll_rad  = math.radians(roll_deg)
        pitch_rad = math.radians(pitch_deg)
        yaw_rad   = 0.0  # if you have no yaw estimate, keep it at 0

        # Convert Euler -> Quaternion
        (qx, qy, qz, qw) = self.euler_to_quaternion(roll_rad, pitch_rad, yaw_rad)

        # Build an IMU message
        imu_msg = Imu()
        imu_msg.header.stamp = self.get_clock().now().to_msg()
        imu_msg.header.frame_id = 'base_link'  

        # Orientation
        imu_msg.orientation.x = qx
        imu_msg.orientation.y = qy
        imu_msg.orientation.z = qz
        imu_msg.orientation.w = qw

        # If you have real angular velocity or linear accel, fill them here.
        # Otherwise, they default to 0. It's fine for simple orientation display.

        self.pub_imu.publish(imu_msg)

        # (optional) debug log
        self.get_logger().info(
            f"Re-published IMU orientation. Roll={roll_deg:.2f}, Pitch={pitch_deg:.2f}"
        )

    def euler_to_quaternion(self, roll, pitch, yaw):
        """
        Convert Euler angles (radians) to a quaternion.
        """
        qr = math.sin(roll/2)*math.cos(pitch/2)*math.cos(yaw/2) \
             - math.cos(roll/2)*math.sin(pitch/2)*math.sin(yaw/2)
        qp = math.cos(roll/2)*math.sin(pitch/2)*math.cos(yaw/2) \
             + math.sin(roll/2)*math.cos(pitch/2)*math.sin(yaw/2)
        qy = math.cos(roll/2)*math.cos(pitch/2)*math.sin(yaw/2) \
             - math.sin(roll/2)*math.sin(pitch/2)*math.cos(yaw/2)
        qw = math.cos(roll/2)*math.cos(pitch/2)*math.cos(yaw/2) \
             + math.sin(roll/2)*math.sin(pitch/2)*math.sin(yaw/2)
        return (qr, qp, qy, qw)

def main(args=None):
    rclpy.init(args=args)
    node = IMUOrientationPublisher()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
