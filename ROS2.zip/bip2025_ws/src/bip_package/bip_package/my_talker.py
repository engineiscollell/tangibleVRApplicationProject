def main():
    print('Hi from bip_package.')


if __name__ == '__main__':
    main()
