import rclpy
from rclpy.node import Node
from geometry_msgs.msg import AccelStamped
import serial

class AccelPublisher(Node):
    def __init__(self):
        super().__init__('accel_publisher')
        
        # Publisher for /accel_data
        self.publisher_ = self.create_publisher(AccelStamped, 'accel_data', 10)
        
        # Open serial port (adjust as needed for your OS)
        self.ser = serial.Serial('/dev/ttyUSB0', 115200, timeout=1)
        
        # Check if port opened
        if not self.ser.is_open:
            raise RuntimeError("Could not open /dev/ttyUSB0")

        # Create timer to read at ~10Hz
        self.timer = self.create_timer(0.1, self.timer_callback)

    def timer_callback(self):
        # Read a line until newline, then strip
        raw_line = self.ser.readline().decode('utf-8', errors='ignore').strip()
        
        if not raw_line:
            return  # Nothing read, skip this cycle
        
        # We expect: x_val,y_val,z_val,roll_val,pitch_val
        vals = raw_line.split(',')
        if len(vals) != 5:
            self.get_logger().warn(f"Unexpected CSV format: {raw_line}")
            return
        
        try:
            x_val = float(vals[0])
            y_val = float(vals[1])
            z_val = float(vals[2])
            roll_deg = float(vals[3])
            pitch_deg = float(vals[4])
        except ValueError:
            self.get_logger().warn(f"Cannot parse float from line: {raw_line}")
            return

        # Build AccelStamped
        msg = AccelStamped()
        msg.header.stamp = self.get_clock().now().to_msg()
        msg.accel.linear.x = x_val
        msg.accel.linear.y = y_val
        msg.accel.linear.z = z_val
        # Put roll/pitch in the angular part (just as a demonstration)
        msg.accel.angular.x = roll_deg
        msg.accel.angular.y = pitch_deg
        msg.accel.angular.z = 0.0

        self.publisher_.publish(msg)
        self.get_logger().info(
            f"Published X:{x_val:.2f} Y:{y_val:.2f} Z:{z_val:.2f} "
            f"Roll:{roll_deg:.2f} Pitch:{pitch_deg:.2f}"
        )


def main(args=None):
    rclpy.init(args=args)
    node = AccelPublisher()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()